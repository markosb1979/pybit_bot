"""
Strategy Manager - Coordinate strategy execution and signal generation

This module loads and manages trading strategies, provides them with data,
and collects generated signals.
"""

import os
import importlib
import inspect
from typing import Dict, List, Optional, Any, Union
import asyncio

from ..utils.logger import Logger
from ..models.signal import Signal, SignalType


class StrategyManager:
    """
    Manages trading strategy loading, execution, and signal collection
    
    Provides a unified interface to all strategies in the system.
    """
    
    def __init__(self, config, data_manager, order_client, logger=None):
        """
        Initialize with configuration, data access, and order client
        
        Args:
            config: Configuration dictionary 
            data_manager: DataManager instance
            order_client: OrderManagerClient instance
            logger: Optional Logger instance
        """
        self.logger = logger or Logger("StrategyManager")
        self.logger.debug(f"→ __init__(config_id={id(config)}, data_manager={data_manager}, order_client={order_client}, logger={logger})")
        
        self.config = config
        self.data_manager = data_manager
        self.order_client = order_client
        
        # Dictionary to store loaded strategies
        self.strategies = {}
        
        # Active strategy instances
        self.active_strategies = {}
        
        # Flag to track if initialized
        self.initialized = False
        
        # Default symbol
        self.default_symbol = self.config.get('general', {}).get('trading', {}).get('default_symbol', "BTCUSDT")
        
        self.logger.debug(f"← __init__ completed")
    
    def initialize(self) -> bool:
        """
        Load and initialize all configured strategies
        
        Returns:
            True if successful, False otherwise
        """
        self.logger.debug(f"→ initialize()")
        
        try:
            # Get strategy configuration
            strategy_config = self.config.get('strategy', {})
            
            # Get active strategy
            active_strategy = strategy_config.get('active_strategy', '')
            self.logger.info(f"Active strategy: {active_strategy}")
            
            # Default symbol
            default_symbol = self.config.get('general', {}).get('trading', {}).get('default_symbol', "BTCUSDT")
            self.logger.info(f"Using default symbol: {default_symbol}")
            
            if not active_strategy:
                self.logger.warning("No active strategy configured")
                self.logger.debug(f"← initialize returned False (no active strategy)")
                return False
                
            # Import the strategy module
            module_path = f"pybit_bot.strategies.{active_strategy}"
            self.logger.info(f"Importing strategy module: {module_path}")
            
            try:
                strategy_module = importlib.import_module(module_path)
                
                # Find all classes in the module
                for name, obj in inspect.getmembers(strategy_module):
                    # Check if it's a class and not imported
                    if inspect.isclass(obj) and obj.__module__ == strategy_module.__name__:
                        # Create an instance of the strategy
                        strategy_instance = obj(
                            self.config,
                            self.data_manager,
                            self.order_client,
                            logger=self.logger
                        )
                        
                        # Store in active strategies
                        self.active_strategies[active_strategy] = strategy_instance
                        self.logger.info(f"Successfully loaded strategy: {active_strategy}")
                        
                        # Strategy loaded successfully
                        self.initialized = True
                        break
                else:
                    self.logger.error(f"No strategy class found in {module_path}")
                    self.logger.debug(f"← initialize returned False (no strategy class found)")
                    return False
                    
            except Exception as e:
                self.logger.error(f"Error loading strategy {active_strategy}: {str(e)}")
                self.logger.debug(f"← initialize returned False (error loading strategy)")
                return False
            
            self.logger.debug(f"← initialize returned True")
            return True
            
        except Exception as e:
            self.logger.error(f"Error initializing StrategyManager: {str(e)}")
            self.logger.debug(f"← initialize returned False (error)")
            return False
    
    async def process_data(self, symbol: str, timeframes: List[str]) -> List[Signal]:
        """
        Process market data through active strategies
        
        Args:
            symbol: Trading symbol
            timeframes: List of timeframes to process
            
        Returns:
            List of generated signals
        """
        self.logger.debug(f"→ process_data(symbol={symbol}, timeframes={timeframes})")
        
        all_signals = []
        
        try:
            if not self.initialized:
                self.logger.warning("StrategyManager not initialized, initializing now")
                if not self.initialize():
                    self.logger.error("Failed to initialize StrategyManager")
                    self.logger.debug(f"← process_data returned empty signal list (not initialized)")
                    return []
            
            # Process each active strategy
            for strategy_name, strategy in self.active_strategies.items():
                self.logger.debug(f"Running {strategy_name} for {symbol} with timeframes: {timeframes}")
                
                try:
                    # Get signals from strategy
                    signals = await strategy.process_data(symbol, timeframes)
                    
                    if signals:
                        self.logger.info(f"Strategy {strategy_name} generated {len(signals)} signals for {symbol}")
                        all_signals.extend(signals)
                        
                        # Log signal details
                        for signal in signals:
                            if signal:
                                self.logger.info(f"Signal: {signal}")
                except Exception as e:
                    self.logger.error(f"Error processing {strategy_name} for {symbol}: {str(e)}")
            
            self.logger.debug(f"← process_data returned {len(all_signals)} signals")
            return all_signals
            
        except Exception as e:
            self.logger.error(f"Error in process_data: {str(e)}")
            self.logger.debug(f"← process_data returned empty signal list (error)")
            return []
    
    def get_indicator_values(self, symbol: str, timeframe: str) -> Dict:
        """
        Get current indicator values for a symbol/timeframe
        
        Args:
            symbol: Trading symbol
            timeframe: Timeframe to use
            
        Returns:
            Dictionary with indicator values
        """
        self.logger.debug(f"→ get_indicator_values(symbol={symbol}, timeframe={timeframe})")
        
        indicator_values = {}
        
        try:
            # Check if initialized
            if not self.initialized:
                self.logger.warning("StrategyManager not initialized")
                self.logger.debug(f"← get_indicator_values returned empty dict (not initialized)")
                return {}
            
            # Get indicator values from each strategy
            for strategy_name, strategy in self.active_strategies.items():
                if hasattr(strategy, 'get_indicator_values'):
                    try:
                        values = strategy.get_indicator_values(symbol, timeframe)
                        if values:
                            indicator_values.update(values)
                    except Exception as e:
                        self.logger.error(f"Error getting indicator values from {strategy_name}: {str(e)}")
            
            self.logger.debug(f"← get_indicator_values returned dict with {len(indicator_values)} indicators")
            return indicator_values
            
        except Exception as e:
            self.logger.error(f"Error in get_indicator_values: {str(e)}")
            self.logger.debug(f"← get_indicator_values returned empty dict (error)")
            return {}
    
    async def backtest(self, symbol: str, timeframe: str, start_date=None, end_date=None) -> Dict:
        """
        Run backtest for a strategy
        
        Args:
            symbol: Trading symbol
            timeframe: Timeframe to use
            start_date: Optional start date
            end_date: Optional end date
            
        Returns:
            Backtest results dictionary
        """
        self.logger.debug(f"→ backtest(symbol={symbol}, timeframe={timeframe}, start_date={start_date}, end_date={end_date})")
        
        results = {
            "trades": [],
            "performance": {},
            "equity_curve": []
        }
        
        try:
            # Check if initialized
            if not self.initialized:
                self.logger.warning("StrategyManager not initialized")
                self.initialize()
            
            # Check if any strategy supports backtesting
            for strategy_name, strategy in self.active_strategies.items():
                if hasattr(strategy, 'backtest'):
                    try:
                        strategy_results = await strategy.backtest(symbol, timeframe, start_date, end_date)
                        if strategy_results:
                            results = strategy_results
                            break
                    except Exception as e:
                        self.logger.error(f"Error backtesting with {strategy_name}: {str(e)}")
            
            self.logger.debug(f"← backtest returned results with {len(results['trades'])} trades")
            return results
            
        except Exception as e:
            self.logger.error(f"Error in backtest: {str(e)}")
            self.logger.debug(f"← backtest returned empty results (error)")
            return results
    
    def optimize(self, symbol: str, timeframe: str, parameters: Dict, start_date=None, end_date=None) -> Dict:
        """
        Optimize strategy parameters
        
        Args:
            symbol: Trading symbol
            timeframe: Timeframe to use
            parameters: Parameters to optimize with ranges
            start_date: Optional start date
            end_date: Optional end date
            
        Returns:
            Optimization results
        """
        self.logger.debug(f"→ optimize(symbol={symbol}, timeframe={timeframe}, parameters={parameters}, start_date={start_date}, end_date={end_date})")
        
        results = {
            "best_params": {},
            "all_results": []
        }
        
        try:
            # Check if initialized
            if not self.initialized:
                self.logger.warning("StrategyManager not initialized")
                self.initialize()
            
            # Check if any strategy supports optimization
            for strategy_name, strategy in self.active_strategies.items():
                if hasattr(strategy, 'optimize'):
                    try:
                        strategy_results = strategy.optimize(symbol, timeframe, parameters, start_date, end_date)
                        if strategy_results:
                            results = strategy_results
                            break
                    except Exception as e:
                        self.logger.error(f"Error optimizing with {strategy_name}: {str(e)}")
            
            self.logger.debug(f"← optimize returned results with {len(results['all_results'])} parameter combinations")
            return results
            
        except Exception as e:
            self.logger.error(f"Error in optimize: {str(e)}")
            self.logger.debug(f"← optimize returned empty results (error)")
            return results