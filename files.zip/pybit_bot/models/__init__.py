"""
Models package for PyBit Bot

Contains data models used throughout the application
"""