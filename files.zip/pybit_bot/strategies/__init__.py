"""
Strategy framework module
"""

# These will be implemented in Phase 3
# from .base import StrategyBase
# from .multi_indicator import MultiIndicatorStrategy

__all__ = []  # Will be populated in Phase 3