"""
Direct test of trading engine functionality
"""
import os
import sys
import time
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

def main():
    """Test trading engine directly"""
    print("=" * 50)
    print("TRADING ENGINE DIRECT TEST")
    print("=" * 50)
    
    # Set up logging
    import logging
    logging.basicConfig(
        level=logging.DEBUG,
        format='%(asctime)s [%(name)s] %(levelname)s: %(message)s',
        handlers=[logging.StreamHandler()]
    )
    
    # Import engine
    try:
        # Try different import patterns until one works
        try:
            from pybit_bot.engine import TradingEngine
            print("✓ Imported engine from pybit_bot.engine")
        except ImportError:
            try:
                from pybit_bot.core.engine import TradingEngine
                print("✓ Imported engine from pybit_bot.core.engine")
            except ImportError:
                try:
                    from pybit_bot.trading.engine import TradingEngine
                    print("✓ Imported engine from pybit_bot.trading.engine")
                except ImportError:
                    print("✗ Could not import TradingEngine")
                    return
        
        # Initialize engine
        config_path = os.path.join("pybit_bot", "configs", "config.json")
        if not os.path.exists(config_path):
            print(f"✗ Config file not found: {config_path}")
            return
        
        print(f"✓ Found config file: {config_path}")
        print("Initializing trading engine...")
        
        engine = TradingEngine(config_path)
        print("✓ Engine initialized")
        
        # Start engine
        print("Starting engine...")
        result = engine.start()
        if result:
            print("✓ Engine started successfully")
        else:
            print("✗ Engine failed to start")
            return
        
        # Run for a short time
        print("Running engine for 30 seconds...")
        for i in range(30):
            print(f"Running: {i+1}/30 seconds")
            time.sleep(1)
        
        # Stop engine
        print("Stopping engine...")
        engine.stop()
        print("✓ Engine stopped")
        
    except Exception as e:
        print(f"✗ Error: {str(e)}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()