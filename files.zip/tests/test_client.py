"""
Test script for BybitClient from client.py

This script tests basic client functionality including:
- Connection to Bybit API
- Authentication
- Basic API endpoints
- Error handling
- Rate limiting behavior
"""

import os
import sys
import asyncio
import time
from dotenv import load_dotenv

# Add project root to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Import the correct client classes
from pybit_bot.core.client import BybitClient as BybitClientTransport  # Use alias for backward compatibility
from pybit_bot.core.client import APICredentials
from pybit_bot.utils.logger import Logger

logger = Logger("TestClient")

# Rest of the test code...