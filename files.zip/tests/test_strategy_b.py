"""
Unit tests for Strategy B implementation.
Tests SMA crossover signal generation and ATR-based stop levels.
"""

import unittest
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import sys
import os

# Add parent directory to the path so imports work correctly
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Update imports to use full package path
from pybit_bot.strategies.strategy_b import StrategyB
from pybit_bot.strategies.base_strategy import SignalType, OrderType


class TestStrategyB(unittest.TestCase):
    """Test suite for Strategy B."""
    
    # Class implementation remains the same...