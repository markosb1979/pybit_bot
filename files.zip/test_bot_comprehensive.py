# ... inside test_positions and test_close_position ...

# Always pass symbol explicitly
positions = self.client.get_positions(symbol="BTCUSDT")