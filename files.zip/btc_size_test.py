#!/usr/bin/env python3
"""
BTC Position Size Test - Focused on $250, $500, $1,000 trades
Tests realistic position sizes for your $4,000 testnet account
"""

import asyncio
import os
import sys
from pathlib import Path
import json
from datetime import datetime

# Add the parent directory to Python path
current_dir = Path(__file__).parent
project_root = current_dir.parent if current_dir.name == "pybit_bot" else current_dir
sys.path.insert(0, str(project_root))

# Import our modules
try:
    from pybit_bot import BybitClient, APICredentials, Logger, ConfigLoader
    from pybit_bot.managers.order_manager import OrderManager
    from pybit_bot.managers.data_manager import DataManager
except ImportError as e:
    print(f"Import error: {e}")
    print(f"Current directory: {os.getcwd()}")
    print(f"Python path: {sys.path}")
    print("Please ensure you're running from the correct directory")
    sys.exit(1)

async def test_btc_position_sizes():
    """Test BTC position sizes for specific USDT amounts"""
    logger = Logger("BTCSizeTest")
    logger.info("=" * 60)
    logger.info("BTC POSITION SIZE TEST - $4,000 ACCOUNT")
    logger.info("=" * 60)
    logger.info(f"Test Date: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC")
    
    try:
        # Load configuration
        config_loader = ConfigLoader()
        
        # Load credentials from environment
        api_key = os.getenv('BYBIT_API_KEY')
        api_secret = os.getenv('BYBIT_API_SECRET')
        testnet = os.getenv('BYBIT_TESTNET', 'true').lower() == 'true'
        
        if not api_key or not api_secret:
            logger.error("API credentials not found in environment")
            return
        
        credentials = APICredentials(
            api_key=api_key,
            api_secret=api_secret,
            testnet=testnet
        )
        
        # Initialize client
        client = BybitClient(credentials, logger)
        
        # Initialize managers
        data_manager = DataManager(client=client, config=config_loader, logger=logger)
        order_manager = OrderManager(client=client, config=config_loader, logger=logger)
        
        await data_manager.initialize()
        await order_manager.initialize()
        
        # Test symbol
        symbol = "BTCUSDT"
        
        # Get account balance
        account_balance = await order_manager.get_account_balance()
        available_balance = float(account_balance.get("totalAvailableBalance", "0"))
        
        logger.info(f"Account Balance: ${available_balance:,.2f} USDT")
        
        # Get current price
        current_price = await data_manager.get_latest_price(symbol)
        logger.info(f"Current {symbol} price: ${current_price:,.2f}")
        
        # Get instrument info for precision details
        instrument_info = client.get_instrument_info(symbol)
        lot_size_filter = {}
        
        if instrument_info and isinstance(instrument_info, dict) and 'list' in instrument_info:
            instrument = instrument_info['list'][0]
            lot_size_filter = instrument.get('lotSizeFilter', {})
            qty_step = lot_size_filter.get('qtyStep', 'Unknown')
            min_qty = lot_size_filter.get('minOrderQty', 'Unknown')
            max_leverage = instrument.get('leverageFilter', {}).get('maxLeverage', 100)
            
            logger.info(f"BTC Contract Specifications:")
            logger.info(f"  - Minimum Order Quantity: {min_qty} BTC")
            logger.info(f"  - Quantity Step: {qty_step} BTC")
            logger.info(f"  - Maximum Leverage: {max_leverage}x")
        
        # Test different USDT amounts specifically requested
        test_amounts = [250, 500, 1000]
        
        # Additional useful amounts based on account size
        account_percentages = [1, 2.5, 5, 10, 25]
        for percentage in account_percentages:
            amount = available_balance * (percentage / 100)
            if amount not in test_amounts:
                test_amounts.append(amount)
        
        # Sort the test amounts
        test_amounts.sort()
        
        # Table header
        logger.info("\nPosition Size Test Results:")
        logger.info("-" * 100)
        logger.info(f"{'USDT Amount':<15} {'% of Account':<15} {'BTC Quantity':<15} {'Actual USD Value':<20} {'Difference':<15}")
        logger.info("-" * 100)
        
        for amount in test_amounts:
            # Calculate position size
            position_size = await order_manager.calculate_position_size(symbol, amount)
            
            # Calculate actual USD value
            actual_usd = float(position_size) * current_price
            
            # Calculate difference
            difference = actual_usd - amount
            diff_percent = (difference / amount) * 100 if amount > 0 else 0
            
            # Calculate percentage of account
            account_percent = (amount / available_balance) * 100 if available_balance > 0 else 0
            
            # Format output
            logger.info(f"${amount:<14,.2f} {account_percent:<14.2f}% {position_size:<15} ${actual_usd:<19,.2f} ${difference:+.2f} ({diff_percent:+.2f}%)")
        
        logger.info("-" * 100)
        
        # Leverage scenarios
        logger.info("\nLeverage Scenarios for $1,000 Position:")
        logger.info("-" * 80)
        logger.info(f"{'Leverage':<10} {'Margin Required':<20} {'% of Account':<15} {'Liquidation Price':<20}")
        logger.info("-" * 80)
        
        position_size_1000 = float(await order_manager.calculate_position_size(symbol, 1000))
        entry_price = current_price
        
        for leverage in [1, 2, 5, 10, 20, 50, 100]:
            margin_required = 1000 / leverage
            account_percent = (margin_required / available_balance) * 100 if available_balance > 0 else 0
            
            # Calculate approximate liquidation price (simplified)
            # For long positions: entry_price * (1 - 1/leverage + maintenance_margin)
            # Using 0.5% as a simplified maintenance margin
            maintenance_margin = 0.005
            liquidation_price = entry_price * (1 - (1/leverage) + maintenance_margin)
            
            logger.info(f"{leverage:<10}x ${margin_required:<19,.2f} {account_percent:<14.2f}% ${liquidation_price:<19,.2f}")
        
        logger.info("-" * 80)
        logger.info("Note: Liquidation prices are approximate and simplified calculations.")
        
        # Risk management suggestions
        logger.info("\nRisk Management Suggestions:")
        logger.info(f"1. For your ${available_balance:.2f} account, consider risking 1-2% per trade (${available_balance*0.01:.2f}-${available_balance*0.02:.2f})")
        logger.info(f"2. With 10x leverage, a ${available_balance*0.1:.2f} position would use 10% of your account as margin")
        logger.info(f"3. Recommended starting position: $250-500 (approx. {(250/available_balance)*100:.1f}%-{(500/available_balance)*100:.1f}% of your account)")
        
    except Exception as e:
        logger.error(f"Error testing position sizes: {e}")
        import traceback
        traceback.print_exc()
    finally:
        # Clean shutdown
        await data_manager.close()
        await order_manager.close()
        logger.info("\nPosition size test complete")

if __name__ == "__main__":
    asyncio.run(test_btc_position_sizes())