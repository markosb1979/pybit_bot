"""
OrderManager - High-level order management abstraction
Uses OrderManagerLib for core trading functionality
"""

import logging
from typing import Dict, List, Optional, Any, Union

from pybit.unified_trading import HTTP as PybitClient

from ..core.order_manager_lib import OrderManagerLib
from ..utils.logger import Logger


class OrderManager:
    """
    Order management abstraction layer for strategy integration
    Provides simple interface for all trading operations
    """
    
    def __init__(self, client, config, logger=None):
        """
        Initialize with client, config, and logger
        
        Args:
            client: BybitClient instance
            config: ConfigLoader instance
            logger: Optional Logger instance
        """
        self.client = client
        self.config = config
        self.logger = logger or Logger("OrderManager")
        
        # Get API credentials from client - handle APICredentials dataclass
        if hasattr(client, "credentials"):
            # Access as attributes instead of dictionary
            self.api_key = getattr(client.credentials, "api_key", "")
            self.api_secret = getattr(client.credentials, "api_secret", "")
            self.testnet = getattr(client.credentials, "testnet", True)
        else:
            # Fallback if credentials not available
            self.api_key = ""
            self.api_secret = ""
            self.testnet = True
            self.logger.warning("No credentials found in client, using defaults")
        
        # Create PybitClient instance
        self.pybit_client = PybitClient(
            api_key=self.api_key,
            api_secret=self.api_secret,
            testnet=self.testnet
        )
        
        # Create order manager lib instance
        self.lib = OrderManagerLib(self.pybit_client, self.logger)
        
        # Default trading settings
        self.default_symbol = config.get("default_symbol", "BTCUSDT")
        self.max_leverage = config.get("max_leverage", 10)
        self.default_qty = config.get("default_quantity", "0.001")
        
        # Order tracking
        self.active_orders = {}
        self.position_history = []
        
        self.logger.info("OrderManager initialized")
    
    def initialize(self):
        """Initialize order manager and connect to API"""
        self.logger.info("OrderManager starting...")
        
        # Initial data fetch for instrument info
        self.lib.get_instrument_info(self.default_symbol)
        
        self.logger.info("OrderManager initialized successfully")
        return True
        
    def close(self):
        """Clean shutdown of order manager"""
        self.logger.info("OrderManager shutting down...")
        # No specific cleanup needed for PyBit REST client
        return True
    
    # ========== CORE TRADING METHODS ==========
    
    def get_positions(self, symbol=None):
        """
        Get current positions
        
        Args:
            symbol: Optional symbol filter
            
        Returns:
            List of position dictionaries
        """
        try:
            symbol = symbol or self.default_symbol
            
            # Use the PybitClient directly
            response = self.pybit_client.get_positions(
                category="linear", 
                symbol=symbol
            )
            
            return response.get("list", [])
            
        except Exception as e:
            self.logger.error(f"Error getting positions: {str(e)}")
            return []
    
    def calculate_position_size(self, symbol, usdt_amount):
        """
        Calculate order size based on USDT amount
        
        Args:
            symbol: Trading pair symbol
            usdt_amount: Amount in USDT to trade
            
        Returns:
            Contract quantity as string
        """
        return self.lib.calculate_position_size(symbol, usdt_amount)
    
    def place_market_order(self, symbol, side, qty):
        """
        Place market order
        
        Args:
            symbol: Trading pair symbol
            side: "Buy" or "Sell"
            qty: Order quantity
            
        Returns:
            Order response dictionary
        """
        return self.lib.place_market_order(symbol, side, qty)
    
    def place_limit_order(self, symbol, side, qty, price):
        """
        Place limit order
        
        Args:
            symbol: Trading pair symbol
            side: "Buy" or "Sell"
            qty: Order quantity
            price: Limit price
            
        Returns:
            Order response dictionary
        """
        return self.lib.place_limit_order(symbol, side, price)
    
    def set_take_profit(self, symbol, price):
        """
        Set take profit for current position
        
        Args:
            symbol: Trading pair symbol
            price: Take profit price
            
        Returns:
            Response dictionary
        """
        return self.lib.set_take_profit(symbol, price)
    
    def set_stop_loss(self, symbol, price):
        """
        Set stop loss for current position
        
        Args:
            symbol: Trading pair symbol
            price: Stop loss price
            
        Returns:
            Response dictionary
        """
        return self.lib.set_stop_loss(symbol, price)
    
    def get_order_status(self, symbol, order_id):
        """
        Check status of a specific order
        
        Args:
            symbol: Trading pair symbol
            order_id: Order ID to check
            
        Returns:
            Order status string
        """
        return self.lib.get_order_status(symbol, order_id)
    
    def cancel_order(self, symbol, order_id):
        """
        Cancel a specific order
        
        Args:
            symbol: Trading pair symbol
            order_id: Order ID to cancel
            
        Returns:
            Cancellation response dictionary
        """
        return self.lib.cancel_order(symbol, order_id)
    
    def close_position(self, symbol):
        """
        Close an entire position
        
        Args:
            symbol: Trading pair symbol
            
        Returns:
            Order response dictionary
        """
        return self.lib.close_position(symbol)
    
    def get_account_balance(self):
        """
        Get account wallet balance
        
        Returns:
            Account balance dictionary
        """
        return self.lib.get_account_balance()
    
    def get_active_orders(self, symbol=None):
        """
        Get all active orders
        
        Args:
            symbol: Optional symbol filter
            
        Returns:
            List of active order dictionaries
        """
        return self.lib.get_active_orders(symbol)
    
    def get_order_history(self, symbol=None):
        """
        Get historical orders
        
        Args:
            symbol: Optional symbol filter
            
        Returns:
            List of historical order dictionaries
        """
        return self.lib.get_order_history(symbol)
    
    # ========== ENHANCED TRADING METHODS ==========
    
    def enter_long_with_tp_sl(self, symbol, qty, tp_price=None, sl_price=None):
        """
        Enter long position with optional TP/SL
        
        Args:
            symbol: Trading pair symbol
            qty: Order quantity
            tp_price: Optional take profit price
            sl_price: Optional stop loss price
            
        Returns:
            Dictionary with order details
        """
        # Place the entry order
        entry_order = self.place_market_order(symbol, "Buy", qty)
        
        if "error" in entry_order:
            return entry_order
            
        # Wait a moment for order execution - no async/await here
        # In synchronous code, we would need to rely on the API's consistency
        
        result = {
            "entry_order": entry_order,
            "tp_order": None,
            "sl_order": None
        }
        
        # Set take profit if specified
        if tp_price:
            tp_order = self.set_take_profit(symbol, tp_price)
            result["tp_order"] = tp_order
            
        # Set stop loss if specified
        if sl_price:
            sl_order = self.set_stop_loss(symbol, sl_price)
            result["sl_order"] = sl_order
            
        return result
    
    def enter_short_with_tp_sl(self, symbol, qty, tp_price=None, sl_price=None):
        """
        Enter short position with optional TP/SL
        
        Args:
            symbol: Trading pair symbol
            qty: Order quantity
            tp_price: Optional take profit price
            sl_price: Optional stop loss price
            
        Returns:
            Dictionary with order details
        """
        # Place the entry order
        entry_order = self.place_market_order(symbol, "Sell", qty)
        
        if "error" in entry_order:
            return entry_order
            
        result = {
            "entry_order": entry_order,
            "tp_order": None,
            "sl_order": None
        }
        
        # Set take profit if specified
        if tp_price:
            tp_order = self.set_take_profit(symbol, tp_price)
            result["tp_order"] = tp_order
            
        # Set stop loss if specified
        if sl_price:
            sl_order = self.set_stop_loss(symbol, sl_price)
            result["sl_order"] = sl_order
            
        return result
    
    def scale_in_position(self, symbol, side, qty, price=None):
        """
        Add to existing position
        
        Args:
            symbol: Trading pair symbol
            side: "Buy" or "Sell"
            qty: Order quantity
            price: Optional limit price (uses market if None)
            
        Returns:
            Order response dictionary
        """
        if price:
            return self.place_limit_order(symbol, side, qty, price)
        else:
            return self.place_market_order(symbol, side, qty)
    
    def scale_out_position(self, symbol, percent=50):
        """
        Reduce position size by percentage
        
        Args:
            symbol: Trading pair symbol
            percent: Percentage to reduce (1-100)
            
        Returns:
            Order response dictionary
        """
        try:
            # Get current position
            positions = self.get_positions(symbol)
            
            if not positions or float(positions[0].get("size", "0")) == 0:
                return {"info": "No position to reduce"}
                
            position = positions[0]
            position_size = float(position.get("size", "0"))
            position_side = position.get("side", "")
            
            if position_size == 0:
                return {"info": "Position size is zero"}
                
            # Calculate reduction size
            reduction = position_size * (percent / 100)
            reduction_qty = self.lib._round_quantity(symbol, reduction)
            
            # Determine order side (opposite of position)
            order_side = "Sell" if position_side == "Buy" else "Buy"
            
            # Place market order to reduce
            response = self.place_market_order(
                symbol=symbol,
                side=order_side,
                qty=reduction_qty
            )
            
            self.logger.info(f"Reduced {symbol} position by {percent}%: {reduction_qty} {order_side}")
            return response
            
        except Exception as e:
            self.logger.error(f"Error scaling out position: {str(e)}")
            return {"error": str(e)}