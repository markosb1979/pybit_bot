"""
Enhanced Order Manager with Trailing Stop Integration for PyBit Bot

This extends the base OrderManager with trailing stop functionality,
allowing for dynamic adjustment of stop-loss levels based on price movement.
"""

from typing import Dict, Optional, Any, List, Tuple
import asyncio
import time
import uuid

from .order_manager import OrderManager, OrderSide, OrderStatus, Order, Position
from .trailing_manager import TrailingManager, TrailingStop, TrailingType, TrailingDirection
from ..core.client import BybitClient
from ..utils.logger import Logger
from ..utils.config_loader import ConfigLoader


class EnhancedOrderManager(OrderManager):
    """
    Enhanced Order Manager with trailing stop support
    """
    
    def __init__(
        self,
        client: BybitClient,
        config: ConfigLoader,
        logger: Optional[Logger] = None
    ):
        super().__init__(client, config, logger)
        
        # Initialize trailing manager
        self.trailing_manager = TrailingManager(config, logger)
        
        # Load trailing stop configuration
        self.trailing_default_percentage = self.config.get("trading.trailing.default_percentage", 0.01)
        self.trailing_activation_offset = self.config.get("trading.trailing.activation_offset", 0.005)
        
        # Track trailing stop orders
        self.trailing_stop_orders = {}
    
    async def initialize(self):
        """Initialize order manager with trailing support"""
        await super().initialize()
        
        # Pass price precision to trailing manager
        for symbol, precision in self.price_precision.items():
            self.trailing_manager.set_price_precision(symbol, precision)
        
        # Start trailing manager
        await self.trailing_manager.start()
        
        return True
    
    async def place_market_order_with_trailing_stop(
        self,
        side: OrderSide,
        usdt_amount: float = None,
        trail_pct: float = None,
        activation_pct: float = None,
        reduce_only: bool = False,
        symbol: str = None
    ) -> Optional[Order]:
        """
        Place a market order with trailing stop-loss
        
        Args:
            side: Order side (BUY/SELL)
            usdt_amount: USDT amount (default: configured position size)
            trail_pct: Trailing percentage (default: configured default percentage)
            activation_pct: Activation price offset percentage (default: configured activation offset)
            reduce_only: Whether this order can only reduce position
            symbol: Symbol to trade (default: configured symbol)
            
        Returns:
            Order object if successful, None otherwise
        """
        # Use configured defaults if not specified
        trail_pct = trail_pct or self.trailing_default_percentage
        activation_pct = activation_pct or self.trailing_activation_offset
        
        # Place the regular market order first
        order = await self.place_market_order(
            side=side,
            usdt_amount=usdt_amount,
            tp_pct=None,  # Don't set TP/SL directly, we'll use trailing
            sl_pct=None,
            reduce_only=reduce_only,
            symbol=symbol
        )
        
        if not order:
            self.logger.error("Failed to place base market order for trailing stop")
            return None
        
        # Get current price (entry price)
        symbol = symbol or self.symbol
        ticker = self.client.get_ticker(symbol)
        current_price = float(ticker.get("lastPrice", 0))
        
        if current_price <= 0:
            self.logger.error(f"Invalid current price for trailing stop: {current_price}")
            return order
        
        # Calculate activation price
        if side == OrderSide.BUY:
            # For long positions, activate when price rises by activation_pct
            activation_price = current_price * (1 + activation_pct)
            direction = TrailingDirection.LONG
        else:
            # For short positions, activate when price falls by activation_pct
            activation_price = current_price * (1 - activation_pct)
            direction = TrailingDirection.SHORT
        
        # Add trailing stop
        trailing_stop = self.trailing_manager.add_trailing_stop(
            symbol=symbol,
            direction=direction,
            trail_type=TrailingType.PERCENTAGE,
            trail_value=trail_pct,
            activation_price=activation_price,
            position_qty=order.qty,
            order_link_id=order.order_link_id
        )
        
        # Store reference to the trailing stop
        self.trailing_stop_orders[order.order_link_id] = trailing_stop
        
        self.logger.info(
            f"Added trailing stop for {order.order_link_id}: "
            f"Activation price: {activation_price:.2f}, "
            f"Trail percentage: {trail_pct:.2%}"
        )
        
        return order
    
    async def update_trailing_stops(self):
        """Update all trailing stops with current prices"""
        for symbol in self.trailing_manager.trailing_stops:
            try:
                # Get current price
                ticker = self.client.get_ticker(symbol)
                current_price = float(ticker.get("lastPrice", 0))
                
                if current_price <= 0:
                    continue
                
                # Update trailing stops and get triggered ones
                triggered_stops = self.trailing_manager.update_trailing_stops(symbol, current_price)
                
                # Execute triggered stops
                for stop in triggered_stops:
                    await self._execute_trailing_stop(stop, current_price)
                    
            except Exception as e:
                self.logger.error(f"Error updating trailing stops for {symbol}: {e}")
    
    async def _execute_trailing_stop(self, stop: TrailingStop, current_price: float):
        """Execute a triggered trailing stop"""
        try:
            self.logger.info(
                f"Executing trailing stop for {stop.symbol}: "
                f"Direction: {stop.direction.value}, "
                f"Stop price: {stop.current_stop_price:.2f}, "
                f"Current price: {current_price:.2f}"
            )
            
            # Determine order side (opposite of position)
            side = OrderSide.SELL if stop.direction == TrailingDirection.LONG else OrderSide.BUY
            
            # Place market order to close the position
            order_link_id = f"trail_{uuid.uuid4().hex[:8]}"
            
            result = self.client.place_order(
                symbol=stop.symbol,
                side=side.value,
                order_type="Market",
                qty=str(stop.position_qty),
                time_in_force="GTC",
                order_link_id=order_link_id,
                reduce_only=True
            )
            
            if result and "orderId" in result:
                self.logger.info(f"Trailing stop order executed: {result['orderId']}")
                
                # Clean up trailing stop reference
                if stop.order_link_id in self.trailing_stop_orders:
                    del self.trailing_stop_orders[stop.order_link_id]
                
                return True
            else:
                self.logger.error(f"Failed to execute trailing stop: {result}")
                return False
                
        except Exception as e:
            self.logger.error(f"Error executing trailing stop: {e}")
            return False
    
    async def cancel_trailing_stop(self, order_link_id: str) -> bool:
        """
        Cancel a trailing stop
        
        Args:
            order_link_id: Order link ID
            
        Returns:
            bool: True if cancelled successfully, False otherwise
        """
        if order_link_id not in self.trailing_stop_orders:
            self.logger.warning(f"No trailing stop found for order {order_link_id}")
            return False
        
        trailing_stop = self.trailing_stop_orders[order_link_id]
        symbol = trailing_stop.symbol
        
        # Remove from trailing manager
        result = self.trailing_manager.remove_trailing_stop(symbol, order_link_id)
        
        # Clean up reference
        if result:
            del self.trailing_stop_orders[order_link_id]
            self.logger.info(f"Cancelled trailing stop for {order_link_id}")
        
        return result
    
    async def cancel_all_trailing_stops(self, symbol: str = None) -> bool:
        """
        Cancel all trailing stops
        
        Args:
            symbol: Symbol to cancel trailing stops for (None for all)
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            # Get order_link_ids to clean up
            to_remove = []
            
            for order_link_id, stop in self.trailing_stop_orders.items():
                if symbol is None or stop.symbol == symbol:
                    to_remove.append(order_link_id)
            
            # Clear trailing stops in manager
            if symbol:
                self.trailing_manager.clear_trailing_stops(symbol)
            else:
                self.trailing_manager.clear_trailing_stops()
            
            # Clean up references
            for order_link_id in to_remove:
                if order_link_id in self.trailing_stop_orders:
                    del self.trailing_stop_orders[order_link_id]
            
            self.logger.info(f"Cancelled all trailing stops{' for '+symbol if symbol else ''}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error cancelling all trailing stops: {e}")
            return False
    
    async def update(self) -> bool:
        """Update order and position status, including trailing stops"""
        try:
            # Update base order manager
            result = await super().update()
            
            # Update trailing stops
            await self.update_trailing_stops()
            
            return result
            
        except Exception as e:
            self.logger.error(f"Error updating enhanced order manager: {e}")
            return False