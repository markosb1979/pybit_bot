"""
Trailing Stop Manager for PyBit Bot

This module is responsible for:
1. Managing trailing stop-loss orders
2. Dynamically adjusting stop-loss levels based on price movement
3. Interfacing with the OrderManager for execution
4. Providing both fixed and percentage-based trailing mechanisms
5. Supporting multiple trailing stop strategies
"""

import time
import asyncio
from typing import Dict, Optional, Any, List
from enum import Enum
from dataclasses import dataclass, field

from ..utils.logger import Logger
from ..utils.config_loader import ConfigLoader


class TrailingType(str, Enum):
    """Type of trailing stop"""
    PERCENTAGE = "percentage"  # Trail by percentage of price
    FIXED = "fixed"            # Trail by fixed price amount
    ATR_MULTIPLE = "atr"       # Trail by multiple of ATR


class TrailingDirection(str, Enum):
    """Direction of the trailing stop"""
    LONG = "long"      # For long positions (trail below price)
    SHORT = "short"    # For short positions (trail above price)


@dataclass
class TrailingStop:
    """
    Trailing stop configuration and state
    """
    symbol: str
    direction: TrailingDirection
    trail_type: TrailingType
    activation_price: float  # Price at which trailing begins
    trail_value: float       # Percentage or fixed amount to trail
    
    # State tracking
    is_active: bool = False
    highest_price: float = 0.0  # For long positions
    lowest_price: float = float('inf')  # For short positions
    current_stop_price: Optional[float] = None
    last_update_time: float = field(default_factory=time.time)
    
    # Order information
    order_link_id: Optional[str] = None
    position_qty: float = 0.0
    
    def activate(self, current_price: float):
        """Activate the trailing stop"""
        self.is_active = True
        
        if self.direction == TrailingDirection.LONG:
            self.highest_price = current_price
            self._calculate_long_stop_price()
        else:
            self.lowest_price = current_price
            self._calculate_short_stop_price()
        
        self.last_update_time = time.time()
    
    def update(self, current_price: float) -> bool:
        """
        Update the trailing stop based on new price
        
        Returns:
            bool: True if stop price changed, False otherwise
        """
        if not self.is_active:
            if self._check_activation(current_price):
                self.activate(current_price)
                return True
            return False
        
        old_stop_price = self.current_stop_price
        
        if self.direction == TrailingDirection.LONG:
            # For long positions, we track the highest price and trail below it
            if current_price > self.highest_price:
                self.highest_price = current_price
                self._calculate_long_stop_price()
                self.last_update_time = time.time()
        else:
            # For short positions, we track the lowest price and trail above it
            if current_price < self.lowest_price:
                self.lowest_price = current_price
                self._calculate_short_stop_price()
                self.last_update_time = time.time()
        
        # Return True if stop price changed
        return old_stop_price != self.current_stop_price
    
    def _check_activation(self, current_price: float) -> bool:
        """Check if the trailing stop should be activated"""
        if self.direction == TrailingDirection.LONG:
            return current_price >= self.activation_price
        else:
            return current_price <= self.activation_price
    
    def _calculate_long_stop_price(self):
        """Calculate stop price for long positions"""
        if self.trail_type == TrailingType.PERCENTAGE:
            # Trail by percentage below highest price
            self.current_stop_price = self.highest_price * (1 - self.trail_value)
        elif self.trail_type == TrailingType.FIXED:
            # Trail by fixed amount below highest price
            self.current_stop_price = self.highest_price - self.trail_value
        elif self.trail_type == TrailingType.ATR_MULTIPLE:
            # This would be calculated based on ATR value passed in at creation
            # For now, treat it like fixed
            self.current_stop_price = self.highest_price - self.trail_value
    
    def _calculate_short_stop_price(self):
        """Calculate stop price for short positions"""
        if self.trail_type == TrailingType.PERCENTAGE:
            # Trail by percentage above lowest price
            self.current_stop_price = self.lowest_price * (1 + self.trail_value)
        elif self.trail_type == TrailingType.FIXED:
            # Trail by fixed amount above lowest price
            self.current_stop_price = self.lowest_price + self.trail_value
        elif self.trail_type == TrailingType.ATR_MULTIPLE:
            # This would be calculated based on ATR value passed in at creation
            # For now, treat it like fixed
            self.current_stop_price = self.lowest_price + self.trail_value
    
    def is_triggered(self, current_price: float) -> bool:
        """
        Check if the trailing stop is triggered
        
        Args:
            current_price: Current market price
            
        Returns:
            bool: True if stop is triggered, False otherwise
        """
        if not self.is_active or self.current_stop_price is None:
            return False
        
        if self.direction == TrailingDirection.LONG:
            # For long positions, stop is triggered when price falls below stop price
            return current_price <= self.current_stop_price
        else:
            # For short positions, stop is triggered when price rises above stop price
            return current_price >= self.current_stop_price


class TrailingManager:
    """
    Manages trailing stops for the trading bot
    """
    
    def __init__(
        self,
        config: ConfigLoader,
        logger: Optional[Logger] = None
    ):
        self.config = config
        self.logger = logger or Logger("TrailingManager")
        
        # Trailing stops by symbol and direction
        self.trailing_stops: Dict[str, List[TrailingStop]] = {}
        
        # Symbol precision info
        self.price_precision: Dict[str, int] = {}
        
        # Trailing configuration
        self.update_interval = self.config.get("trailing.update_interval", 1.0)  # seconds
        self.default_trail_percentage = self.config.get("trailing.default_percentage", 0.01)  # 1%
        
        # Initialize flag
        self.initialized = False
        self.running = False
        self.update_task = None
    
    def set_price_precision(self, symbol: str, precision: int):
        """Set price precision for a symbol"""
        self.price_precision[symbol] = precision
    
    def _round_price(self, price: float, symbol: str) -> float:
        """Round price to symbol precision"""
        precision = self.price_precision.get(symbol, 2)
        return round(price, precision)
    
    def add_trailing_stop(
        self,
        symbol: str,
        direction: TrailingDirection,
        trail_type: TrailingType,
        trail_value: float,
        activation_price: float,
        position_qty: float,
        order_link_id: Optional[str] = None
    ) -> TrailingStop:
        """
        Add a new trailing stop
        
        Args:
            symbol: Trading symbol
            direction: LONG or SHORT
            trail_type: PERCENTAGE, FIXED, or ATR_MULTIPLE
            trail_value: Value to trail by (percentage, fixed amount, or ATR multiple)
            activation_price: Price at which trailing begins
            position_qty: Position quantity
            order_link_id: Associated order ID
            
        Returns:
            TrailingStop: The created trailing stop
        """
        # Create trailing stop
        trailing_stop = TrailingStop(
            symbol=symbol,
            direction=direction,
            trail_type=trail_type,
            trail_value=trail_value,
            activation_price=activation_price,
            position_qty=position_qty,
            order_link_id=order_link_id
        )
        
        # Add to collection
        if symbol not in self.trailing_stops:
            self.trailing_stops[symbol] = []
        
        self.trailing_stops[symbol].append(trailing_stop)
        
        self.logger.info(
            f"Added {direction.value} trailing stop for {symbol}: "
            f"Activation: {activation_price}, Trail: {trail_value} "
            f"({trail_type.value})"
        )
        
        return trailing_stop
    
    def remove_trailing_stop(self, symbol: str, order_link_id: str) -> bool:
        """
        Remove a trailing stop
        
        Args:
            symbol: Trading symbol
            order_link_id: Order link ID
            
        Returns:
            bool: True if removed, False if not found
        """
        if symbol not in self.trailing_stops:
            return False
        
        # Find and remove the trailing stop
        for i, stop in enumerate(self.trailing_stops[symbol]):
            if stop.order_link_id == order_link_id:
                self.trailing_stops[symbol].pop(i)
                self.logger.info(f"Removed trailing stop for {symbol}: {order_link_id}")
                return True
        
        return False
    
    def get_trailing_stops(self, symbol: str) -> List[TrailingStop]:
        """
        Get all trailing stops for a symbol
        
        Args:
            symbol: Trading symbol
            
        Returns:
            List[TrailingStop]: List of trailing stops
        """
        return self.trailing_stops.get(symbol, [])
    
    def clear_trailing_stops(self, symbol: Optional[str] = None):
        """
        Clear all trailing stops for a symbol or all symbols
        
        Args:
            symbol: Symbol to clear (None for all)
        """
        if symbol:
            if symbol in self.trailing_stops:
                self.trailing_stops[symbol] = []
                self.logger.info(f"Cleared all trailing stops for {symbol}")
        else:
            self.trailing_stops = {}
            self.logger.info("Cleared all trailing stops")
    
    def update_trailing_stops(self, symbol: str, current_price: float) -> List[TrailingStop]:
        """
        Update trailing stops for a symbol and get triggered stops
        
        Args:
            symbol: Trading symbol
            current_price: Current market price
            
        Returns:
            List[TrailingStop]: Triggered trailing stops
        """
        if symbol not in self.trailing_stops:
            return []
        
        triggered_stops = []
        
        for stop in self.trailing_stops[symbol]:
            # Update stop price
            price_changed = stop.update(current_price)
            
            if price_changed and stop.is_active:
                self.logger.info(
                    f"Updated {stop.direction.value} trailing stop for {symbol}: "
                    f"Stop price: {stop.current_stop_price:.2f}, "
                    f"Current price: {current_price:.2f}"
                )
            
            # Check if triggered
            if stop.is_triggered(current_price):
                self.logger.info(
                    f"Trailing stop triggered for {symbol}: "
                    f"Stop price: {stop.current_stop_price:.2f}, "
                    f"Current price: {current_price:.2f}"
                )
                triggered_stops.append(stop)
        
        # Remove triggered stops
        for stop in triggered_stops:
            self.trailing_stops[symbol].remove(stop)
        
        return triggered_stops
    
    async def start(self):
        """Start the trailing manager"""
        if self.running:
            return
        
        self.running = True
        self.update_task = asyncio.create_task(self._update_loop())
        self.logger.info("Trailing manager started")
    
    async def stop(self):
        """Stop the trailing manager"""
        if not self.running:
            return
        
        self.running = False
        if self.update_task:
            self.update_task.cancel()
            self.update_task = None
        
        self.logger.info("Trailing manager stopped")
    
    async def _update_loop(self):
        """Update loop for trailing stops"""
        try:
            while self.running:
                # This is a placeholder - actual price updates will come from
                # the data manager in the full implementation
                await asyncio.sleep(self.update_interval)
                
                # The actual update logic will be implemented in the main bot
                # which will call update_trailing_stops with current prices
                
        except asyncio.CancelledError:
            self.logger.info("Trailing update loop cancelled")
        except Exception as e:
            self.logger.error(f"Error in trailing update loop: {e}")
            self.running = False