"""
Command line interface for the pybit_bot trading system
"""

import os
import sys
import argparse
import logging
from datetime import datetime

from ..engine import TradingEngine
from ..utils.logger import Logger

logger = Logger("BotRunner")

def start_bot(args):
    """
    Start the trading bot with the specified configuration
    
    Args:
        args: Command line arguments
    """
    try:
        # Get config directory from args and ensure it's the directory, not a file
        config_path = args.config
        
        # If it's a path ending with config.json, strip it off to get the directory
        if config_path.endswith('config.json'):
            config_dir = os.path.dirname(config_path)
            logger.info(f"Config path appears to point to a config.json file that doesn't exist. Using directory instead: {config_dir}")
            print(f"Using config directory: {config_dir}")
        else:
            config_dir = config_path
        
        # Verify the directory exists and contains the required JSON files
        if os.path.isdir(config_dir):
            # Check for required config files
            required_files = ['general.json', 'indicators.json', 'strategy.json', 'execution.json']
            found_files = [f for f in required_files if os.path.exists(os.path.join(config_dir, f))]
            
            if not found_files:
                logger.error(f"No config files found in {config_dir}")
                print(f"ERROR: No config files found in {config_dir}")
                return
                
            missing_files = [f for f in required_files if f not in found_files]
            if missing_files:
                logger.warning(f"Missing some config files: {missing_files}")
                print(f"WARNING: Missing some config files: {missing_files}")
        else:
            logger.error(f"Config directory does not exist: {config_dir}")
            print(f"ERROR: Config directory does not exist: {config_dir}")
            return
        
        logger.info(f"Initializing trading engine with config directory: {config_dir}")
        print(f"Initializing trading engine with config directory: {config_dir}")
        
        # Initialize the trading engine with the directory path
        engine = TradingEngine(config_dir)
        
        # Initialize components
        if not engine.initialize():
            logger.error("Failed to initialize trading engine")
            print("ERROR: Failed to initialize trading engine")
            return
            
        # Start trading
        if engine.start():
            logger.info("Trading engine started successfully")
            print("Trading engine started successfully")
            
            # Keep process running until interrupted
            try:
                print("Press CTRL+C to stop the bot")
                while engine.is_running:
                    # Sleep briefly to avoid high CPU usage
                    import time
                    time.sleep(1)
            except KeyboardInterrupt:
                logger.info("Keyboard interrupt received, stopping engine")
                print("Stopping trading engine...")
                engine.stop()
        else:
            logger.error("Failed to start trading engine")
            print("ERROR: Failed to start trading engine")
            
    except Exception as e:
        logger.error(f"Error running trading bot: {str(e)}")
        print(f"Error running trading bot: {str(e)}")

def main():
    """Main entry point for CLI"""
    parser = argparse.ArgumentParser(description="PyBit Bot - Automated trading for Bybit")
    
    # Create subparsers for different commands
    subparsers = parser.add_subparsers(dest="command", help="Command to run")
    
    # Start command
    start_parser = subparsers.add_parser("start", help="Start the trading bot")
    
    # Default to the configs directory rather than a specific file
    default_config_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "configs")
    
    start_parser.add_argument(
        "--config", 
        default=default_config_dir,
        help="Path to config directory"
    )
    
    # Parse arguments
    args = parser.parse_args()
    
    # Execute command
    if args.command == "start":
        start_bot(args)
    else:
        parser.print_help()

if __name__ == "__main__":
    main()