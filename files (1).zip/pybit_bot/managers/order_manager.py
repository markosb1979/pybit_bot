"""
Order Manager - Handles order creation, tracking, and execution
"""

import logging
import time
import uuid
import json
import asyncio
import os
import csv
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime

from pybit_bot.core.client import BybitClient
from pybit_bot.core.order_manager_client import OrderManagerClient
from pybit_bot.utils.logger import Logger
from pybit_bot.exceptions import InvalidOrderError  # Remove OrderExecutionError

# Define OrderExecutionError locally
class OrderExecutionError(Exception):
    """Exception raised when an order fails to execute"""
    pass


class OrderManager:
    """
    OrderManager handles all trading execution, order placement,
    and position tracking
    """
    
    def __init__(self, client: BybitClient, config: Dict, logger=None, data_manager=None):
        """
        Initialize the order manager.
        
        Args:
            client: BybitClient instance
            config: Configuration dictionary for execution settings
            logger: Optional logger instance
            data_manager: DataManager instance for market data
        """
        self.client = client
        self.config = config
        self.logger = logger or Logger("OrderManager")
        self.data_manager = data_manager  # Store the data_manager for ATR calculations
        
        # Initialize OrderManagerClient
        self.order_client = OrderManagerClient(client, logger, config)
        
        self.active_orders = {}  # Track active orders
        self.order_history = {}  # Track order history
        self.positions = {}      # Track current positions
        self.pending_tpsl = {}   # Track orders waiting for TP/SL to be set
        
        # Extract configuration
        self.position_config = config.get('position_sizing', {})
        self.risk_config = config.get('risk_management', {})
        self.order_config = config.get('order_execution', {})
        
        self.logger.info("OrderManager initialized")
    
    async def initialize(self):
        """
        Initialize order manager, load existing positions and orders.
        """
        try:
            # Load existing positions
            self.logger.info("Loading existing positions...")
            # Make sure to provide a symbol to get_positions
            symbols = self.config.get('general', {}).get('trading', {}).get('symbols', ["BTCUSDT"])
            default_symbol = symbols[0] if symbols else "BTCUSDT"
            positions = self.order_client.get_positions(default_symbol)
            
            for position in positions:
                symbol = position.get('symbol')
                if symbol:
                    self.positions[symbol] = position
                    
            self.logger.info(f"Loaded {len(self.positions)} existing positions")
            
            # Load open orders
            self.logger.info("Loading open orders...")
            open_orders = self.order_client.get_open_orders(default_symbol)
            
            for order in open_orders:
                order_id = order.get('orderId')
                if order_id:
                    self.active_orders[order_id] = order
            
            self.logger.info(f"Loaded {len(self.active_orders)} open orders")
            
            return True
        except Exception as e:
            self.logger.error(f"Error initializing OrderManager: {str(e)}")
            return False
    
    async def get_account_balance(self):
        """
        Get account balance.
        
        Returns:
            Dictionary containing balance information
        """
        try:
            self.logger.info("Getting account balance...")
            balance_data = self.order_client.get_account_balance()
            
            # Debug log the result
            self.logger.info(f"Balance data received: {balance_data}")
            
            return balance_data
            
        except Exception as e:
            self.logger.error(f"Error getting account balance: {str(e)}")
            # For testing, return a valid default
            return {"totalAvailableBalance": "1000.0"}
    
    async def get_current_price(self, symbol: str) -> float:
        """
        Get the current price for a symbol.
        
        Args:
            symbol: Trading symbol
            
        Returns:
            Current price as float
        """
        try:
            # Get ticker from the client
            ticker = self.client.get_ticker(symbol)
            price = float(ticker.get('lastPrice', 0))
            
            if price <= 0:
                self.logger.error(f"Invalid price for {symbol}: {price}")
                return 0.0
                
            self.logger.info(f"Current price for {symbol}: {price}")
            return price
        except Exception as e:
            self.logger.error(f"Error getting current price for {symbol}: {str(e)}")
            return 0.0
    
    async def calculate_position_size(self, symbol: str, amount_usdt: float) -> float:
        """
        Calculate position size in coins based on USDT amount.
        
        Args:
            symbol: Trading symbol
            amount_usdt: Amount in USDT
            
        Returns:
            Position size in coins
        """
        try:
            # Use OrderManagerClient to calculate position size
            size_str = self.order_client.calculate_position_size(symbol, amount_usdt)
            position_size = float(size_str)
            
            self.logger.info(f"Calculated position size for {symbol}: {position_size}")
            return position_size
            
        except Exception as e:
            self.logger.error(f"Error calculating position size: {str(e)}")
            return 0.0
    
    async def enter_position_market(
        self,
        symbol: str,
        side: str,
        qty: float = None,
        usdt_amount: float = None,
        tp_price: str = None,  # Added TP/SL params for single-call entry
        sl_price: str = None
    ) -> Dict:
        """
        Enter a position with a market order, optionally with TP/SL.
        
        Args:
            symbol: Trading symbol
            side: "Buy" or "Sell"
            qty: Position size (optional if usdt_amount provided)
            usdt_amount: Amount in USDT to use for position (optional if qty provided)
            tp_price: Optional take profit price
            sl_price: Optional stop loss price
            
        Returns:
            Dictionary with order results including fill information
        """
        try:
            direction = "LONG" if side == "Buy" else "SHORT"
            
            # Check if at least one of qty or usdt_amount is provided
            if qty is None and usdt_amount is None:
                error_msg = "Either qty or usdt_amount must be provided"
                self.logger.error(error_msg)
                raise ValueError(error_msg)
            
            # Calculate position size if qty is not provided
            if qty is None:
                self.logger.info(f"Entering {direction} position for {symbol}, amount={usdt_amount} USDT")
                qty = float(self.order_client.calculate_position_size(symbol, usdt_amount))
            else:
                self.logger.info(f"Entering {direction} position for {symbol}, qty={qty}")
            
            # Place order using OrderManagerClient with TP/SL in a single call if provided
            order_params = {
                "symbol": symbol,
                "side": side,
                "order_type": "Market",
                "qty": str(qty)
            }
            
            # Add TP/SL if provided
            if tp_price:
                order_params["take_profit"] = tp_price
            
            if sl_price:
                order_params["stop_loss"] = sl_price
            
            order = self.order_client.place_active_order(**order_params)
            
            self.logger.info(f"{direction} order result: {order}")
            
            # Track the order
            if 'orderId' in order:
                order_id = order['orderId']
                self.active_orders[order_id] = {
                    'symbol': symbol,
                    'side': side,
                    'direction': direction,
                    'quantity': qty,
                    'order_type': 'Market',
                    'status': 'Created',
                    'order_id': order_id,
                    'timestamp': int(time.time() * 1000),
                    'needs_tpsl': not (tp_price and sl_price)  # Only mark as needing TP/SL if not provided in order
                }
                
                # Only add to pending TP/SL if not provided in the order
                if not (tp_price and sl_price):
                    self.pending_tpsl[order_id] = {
                        'symbol': symbol,
                        'side': side,
                        'direction': direction,
                        'quantity': qty,
                        'order_id': order_id
                    }
            
            return order
            
        except Exception as e:
            self.logger.error(f"Error entering {side} position: {str(e)}")
            return {"error": str(e)}
    
    async def set_position_tpsl(self, symbol: str, position_idx: int, tp_price: str, sl_price: str) -> Dict:
        """
        Set TP/SL for an existing position.
        
        Args:
            symbol: Trading symbol
            position_idx: Position index (0 for one-way mode)
            tp_price: Take profit price
            sl_price: Stop loss price
            
        Returns:
            Dictionary with TP/SL setting result
        """
        try:
            self.logger.info(f"Setting TP/SL for {symbol} position: TP={tp_price}, SL={sl_price}")
            
            # Get mark price for validation
            mark_price = 0
            try:
                positions = self.order_client.get_positions(symbol)
                if positions:
                    mark_price = float(positions[0].get("markPrice", 0))
                
                if mark_price <= 0:
                    # Fallback to current price
                    mark_price = await self.get_current_price(symbol)
            except Exception as e:
                self.logger.error(f"Error getting mark price: {str(e)}")
                # Fallback to current price
                mark_price = await self.get_current_price(symbol)
                
            # Convert prices to float for validation
            tp_price_float = float(tp_price)
            sl_price_float = float(sl_price)
            
            # Get position side
            position_side = "UNKNOWN"
            if positions and len(positions) > 0:
                side_raw = positions[0].get("side", "")
                position_side = "LONG" if side_raw == "Buy" else "SHORT"
            
            # Validate against mark price
            if position_side == "LONG":
                # Clamp against mark price for LONG
                if tp_price_float <= mark_price:
                    tp_price_float = mark_price * 1.002
                    tp_price = self.order_client._round_price(symbol, tp_price_float)
                    self.logger.warning(f"Adjusted TP above mark: {tp_price}")
                if sl_price_float >= mark_price:
                    sl_price_float = mark_price * 0.998
                    sl_price = self.order_client._round_price(symbol, sl_price_float)
                    self.logger.warning(f"Adjusted SL below mark: {sl_price}")
            elif position_side == "SHORT":
                # Clamp against mark price for SHORT
                if tp_price_float >= mark_price:
                    tp_price_float = mark_price * 0.998
                    tp_price = self.order_client._round_price(symbol, tp_price_float)
                    self.logger.warning(f"Adjusted TP below mark: {tp_price}")
                if sl_price_float <= mark_price:
                    sl_price_float = mark_price * 1.002
                    sl_price = self.order_client._round_price(symbol, sl_price_float)
                    self.logger.warning(f"Adjusted SL above mark: {sl_price}")
            
            # Use set_position_tpsl in OrderManagerClient
            result = self.order_client.set_position_tpsl(
                symbol=symbol,
                position_idx=position_idx,
                tp_price=tp_price,
                sl_price=sl_price
            )
            
            self.logger.info(f"Set TP/SL result: {result}")
            return result
            
        except Exception as e:
            self.logger.error(f"Error setting TP/SL: {str(e)}")
            return {"error": str(e)}
    
    async def get_position_fill_info(self, symbol: str, order_id: str) -> Dict:
        """
        Get fill information for a position by order ID.
        
        Args:
            symbol: Trading symbol
            order_id: Order ID that created the position
            
        Returns:
            Dictionary with fill information including price
        """
        try:
            # Use OrderManagerClient to get fill info
            fill = self.order_client.get_order_fill_info(symbol, order_id)
            
            self.logger.info(f"Fill info for {order_id}: {fill}")
            return fill
                
        except Exception as e:
            self.logger.error(f"Error getting position fill info: {str(e)}")
            return {'filled': False, 'error': str(e)}
    
    async def enter_long_with_tp_sl(self, symbol: str, qty: float, tp_price: str, sl_price: str) -> Dict:
        """
        Enter a long position with take profit and stop loss.
        THIS METHOD IS MAINTAINED FOR BACKWARDS COMPATIBILITY
        New code should use enter_position_market with tp_price and sl_price parameters
        
        Args:
            symbol: Trading symbol
            qty: Position size
            tp_price: Take profit price
            sl_price: Stop loss price
            
        Returns:
            Dictionary with order results
        """
        try:
            self.logger.info(f"Entering LONG position for {symbol}, qty={qty}, TP={tp_price}, SL={sl_price}")
            
            # Use enter_position_market with TP/SL in a single call
            order_result = await self.enter_position_market(
                symbol=symbol,
                side="Buy",
                qty=qty,
                tp_price=tp_price,
                sl_price=sl_price
            )
            
            self.logger.info(f"Long order result: {order_result}")
            
            # Track the order
            if 'orderId' in order_result:
                order_id = order_result['orderId']
                self.active_orders[order_id] = {
                    'symbol': symbol,
                    'side': 'Buy',
                    'quantity': qty,
                    'order_type': 'Market',
                    'take_profit': tp_price,
                    'stop_loss': sl_price,
                    'status': 'Created',
                    'order_id': order_id,
                    'timestamp': int(time.time() * 1000),
                    'needs_tpsl': False  # TP/SL already set
                }
            
            return {
                "entry_order": order_result,
                "tp_order": None,
                "sl_order": None
            }
            
        except Exception as e:
            self.logger.error(f"Error entering long position: {str(e)}")
            return {
                "entry_order": {"error": str(e)},
                "tp_order": None,
                "sl_order": None
            }
    
    async def enter_short_with_tp_sl(self, symbol: str, qty: float, tp_price: str, sl_price: str) -> Dict:
        """
        Enter a short position with take profit and stop loss.
        THIS METHOD IS MAINTAINED FOR BACKWARDS COMPATIBILITY
        New code should use enter_position_market with tp_price and sl_price parameters
        
        Args:
            symbol: Trading symbol
            qty: Position size
            tp_price: Take profit price
            sl_price: Stop loss price
            
        Returns:
            Dictionary with order results
        """
        try:
            self.logger.info(f"Entering SHORT position for {symbol}, qty={qty}, TP={tp_price}, SL={sl_price}")
            
            # Use enter_position_market with TP/SL in a single call
            order_result = await self.enter_position_market(
                symbol=symbol,
                side="Sell",
                qty=qty,
                tp_price=tp_price,
                sl_price=sl_price
            )
            
            self.logger.info(f"Short order result: {order_result}")
            
            # Track the order
            if 'orderId' in order_result:
                order_id = order_result['orderId']
                self.active_orders[order_id] = {
                    'symbol': symbol,
                    'side': 'Sell',
                    'quantity': qty,
                    'order_type': 'Market',
                    'take_profit': tp_price,
                    'stop_loss': sl_price,
                    'status': 'Created',
                    'order_id': order_id,
                    'timestamp': int(time.time() * 1000),
                    'needs_tpsl': False  # TP/SL already set
                }
            
            return {
                "entry_order": order_result,
                "tp_order": None,
                "sl_order": None
            }
            
        except Exception as e:
            self.logger.error(f"Error entering short position: {str(e)}")
            return {
                "entry_order": {"error": str(e)},
                "tp_order": None,
                "sl_order": None
            }
    
    async def close_position(self, symbol: str) -> Dict:
        """
        Close an open position.
        
        Args:
            symbol: Trading symbol
            
        Returns:
            Dictionary with close result
        """
        try:
            self.logger.info(f"Closing position for {symbol}")
            
            # Use OrderManagerClient to close position
            result = self.order_client.close_position(symbol)
            
            self.logger.info(f"Close position result: {result}")
            
            return {"success": True, "result": result}
            
        except Exception as e:
            self.logger.error(f"Error closing position: {str(e)}")
            return {"success": False, "error": str(e)}
    
    async def update_tp_sl(self, symbol: str, tp_price: Optional[str] = None, sl_price: Optional[str] = None) -> Dict:
        """
        Update take profit and stop loss for an open position.
        
        Args:
            symbol: Trading symbol
            tp_price: New take profit price
            sl_price: New stop loss price
            
        Returns:
            Dictionary with update result
        """
        try:
            self.logger.info(f"Updating TP/SL for {symbol}: TP={tp_price}, SL={sl_price}")
            
            if not tp_price and not sl_price:
                return {"success": False, "message": "No TP or SL provided"}
            
            # Get position
            positions = self.order_client.get_positions(symbol)
            position = None
            
            for pos in positions:
                if pos.get('symbol') == symbol:
                    position = pos
                    break
            
            if not position or float(position.get('size', '0')) == 0:
                self.logger.warning(f"No position to update TP/SL for {symbol}")
                return {"success": False, "message": "No position found"}
            
            # Position ID
            position_idx = position.get('positionIdx', 0)
            
            # Use amend_order in OrderManagerClient if there's an open order with TP/SL
            # Otherwise, use set_trading_stop
            
            # Check if we have any active orders with this symbol that have TP/SL
            active_order_id = None
            for order_id, order in self.active_orders.items():
                if order.get('symbol') == symbol:
                    active_order_id = order_id
                    break
            
            if active_order_id:
                # Try to amend the order
                result = self.order_client.amend_order(
                    symbol=symbol,
                    order_id=active_order_id,
                    take_profit=tp_price,
                    stop_loss=sl_price
                