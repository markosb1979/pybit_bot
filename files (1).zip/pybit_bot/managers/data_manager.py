"""
Data Manager - Handle all market data operations and caching
"""

import asyncio
import logging
import time
import pandas as pd
from typing import Dict, List, Optional, Any, Union
from datetime import datetime, timedelta

from ..utils.logger import Logger
from ..core.order_manager_client import OrderManagerClient


class DataManager:
    """
    Data management system for market data
    Provides price, orderbook, and ticker data with caching
    """
    
    def __init__(self, client, config, logger=None, order_client=None):
        """
        Initialize with client, config, and logger
        
        Args:
            client: BybitClientTransport instance
            config: ConfigLoader instance
            logger: Optional Logger instance
            order_client: Optional OrderManagerClient instance
        """
        self.client = client
        self.config = config
        self.logger = logger or Logger("DataManager")
        # Store the order_client for business logic operations
        self.order_client = order_client
        
        # Default settings
        trading_config = config.get("trading", {})
        self.default_symbol = trading_config.get("default_symbol", "BTCUSDT")
        
        # Data caches with timestamps
        self._price_cache = {}
        self._ticker_cache = {}
        self._orderbook_cache = {}
        self._kline_cache = {}
        self._formatted_kline_cache = {}  # For formatted klines with named columns
        
        # Cache TTL in seconds
        system_config = config.get("system", {})
        self.price_ttl = system_config.get("price_cache_ttl", 1)  # 1 second for prices
        self.ticker_ttl = system_config.get("ticker_cache_ttl", 5)  # 5 seconds for tickers
        self.orderbook_ttl = system_config.get("orderbook_cache_ttl", 2)  # 2 seconds for orderbook
        self.kline_ttl = system_config.get("kline_cache_ttl", 60)  # 60 seconds for klines
        
        # Standard column names for kline data
        self.kline_columns = ['timestamp', 'open', 'high', 'low', 'close', 'volume', 'turnover']
        
        # WebSocket connection state
        self.ws_connected = False
        self.ws_last_update = None
        self.ws_subscriptions = set()

        # Last price for non-async methods
        self._last_price = {}
        
        self.logger.info("DataManager initialized")
    
    async def initialize(self):
        """Initialize data manager and connect to WebSocket"""
        self.logger.info("DataManager starting...")
        
        try:
            # Initialize ticker cache with current data
            ticker = None
            
            # Try using order_client first, then fall back to client
            if self.order_client:
                ticker = self.order_client.get_ticker(self.default_symbol)
            else:
                # Use transport layer as fallback
                if hasattr(self.client, 'get_ticker'):
                    ticker = self.client.get_ticker(self.default_symbol)
                else:
                    self.logger.warning("No method to get ticker available - both order_client and client lack get_ticker")
            
            if ticker:
                self._ticker_cache[self.default_symbol] = {
                    "data": ticker,
                    "timestamp": time.time()
                }
                # Also initialize the last price for this symbol
                self._last_price[self.default_symbol] = float(ticker.get("lastPrice", 0))
                self.logger.info(f"Initial ticker loaded for {self.default_symbol}")
            
            # WebSocket initialization would go here in the future
            # For now, we'll use polling for data updates
            
            # Create a background task for updating data
            self._update_task = asyncio.create_task(self._data_update_loop())
            
            self.logger.info("DataManager initialized successfully")
            return True
            
        except Exception as e:
            self.logger.error(f"Error initializing DataManager: {str(e)}")
            return False
    
    async def close(self):
        """Clean shutdown of data manager"""
        self.logger.info("DataManager shutting down...")
        
        try:
            # Cancel the update task if it exists
            if hasattr(self, '_update_task') and self._update_task:
                self._update_task.cancel()
                try:
                    await self._update_task
                except asyncio.CancelledError:
                    pass
            
            # Close WebSocket connection if active
            # This would be implemented in the future
            
            self.logger.info("DataManager shutdown complete")
            return True
            
        except Exception as e:
            self.logger.error(f"Error closing DataManager: {str(e)}")
            return False
    
    async def _data_update_loop(self):
        """Background task to periodically update market data"""
        try:
            while True:
                # Update ticker for default symbol
                await self._update_ticker(self.default_symbol)
                
                # Sleep for a short interval
                await asyncio.sleep(5)  # Update every 5 seconds
                
        except asyncio.CancelledError:
            self.logger.info("Data update loop cancelled")
        except Exception as e:
            self.logger.error(f"Error in data update loop: {str(e)}")
    
    async def _update_ticker(self, symbol):
        """Update ticker data for a symbol"""
        try:
            ticker = None
            
            # Try using order_client first, then fall back to client
            if self.order_client:
                ticker = self.order_client.get_ticker(symbol)
            elif hasattr(self.client, 'get_ticker'):
                ticker = self.client.get_ticker(symbol)
                
            if ticker:
                self._ticker_cache[symbol] = {
                    "data": ticker,
                    "timestamp": time.time()
                }
                # Also update price cache
                price = float(ticker.get("lastPrice", 0))
                self._price_cache[symbol] = {
                    "price": price,
                    "timestamp": time.