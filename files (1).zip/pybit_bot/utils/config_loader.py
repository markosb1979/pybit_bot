"""
Configuration loader module to centralize config loading logic
"""

import json
import os
import glob
from typing import Dict, Any, List

from .logger import Logger

class ConfigLoader:
    """
    Centralized configuration loading class
    Loads and validates configuration from JSON files
    """
    
    def __init__(self, config_dir: str = None, logger=None):
        """
        Initialize with config directory path
        
        Args:
            config_dir: Path to configuration directory
            logger: Optional logger instance
        """
        self.logger = logger or Logger("ConfigLoader")
        self.logger.debug(f"→ __init__(config_dir={config_dir})")
        
        # Determine config directory - ensure it's a directory, not a file
        if not config_dir:
            # First, try to locate configs in the repository
            repo_path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
            repo_config_dir = os.path.join(repo_path, "pybit_bot", "configs")
            
            if os.path.exists(repo_config_dir) and os.path.isdir(repo_config_dir):
                self.config_dir = repo_config_dir
                self.logger.info(f"Using repository config directory: {repo_config_dir}")
            else:
                # Fallback to local directory
                self.config_dir = os.path.join(os.getcwd(), "configs")
                self.logger.info(f"Using local config directory: {self.config_dir}")
        else:
            # If it's a file path, extract the directory
            if os.path.isfile(config_dir) or config_dir.endswith('.json'):
                self.config_dir = os.path.dirname(config_dir)
                self.logger.info(f"Using directory from file path: {self.config_dir}")
            else:
                # Use the provided directory path
                self.config_dir = config_dir
                self.logger.info(f"Using provided config directory: {self.config_dir}")
        
        # Ensure config_dir actually exists
        if not os.path.exists(self.config_dir):
            self.logger.warning(f"Config directory does not exist: {self.config_dir}")
            # Try to create it
            try:
                os.makedirs(self.config_dir, exist_ok=True)
                self.logger.info(f"Created config directory: {self.config_dir}")
            except Exception as e:
                self.logger.error(f"Failed to create config directory: {str(e)}")
        
        self.logger.info(f"Using config from: {self.config_dir}")
        
        # Initialize empty config store
        self.config = {}
        self.config_files = []
        
        self.logger.debug(f"← __init__ completed")
    
    def load_configs(self) -> Dict[str, Any]:
        """
        Load all configuration files from the config directory
        
        Returns:
            Dictionary with all configurations merged
        """
        self.logger.debug(f"→ load_configs()")
        
        try:
            # Find all JSON files in the config directory
            config_files = glob.glob(os.path.join(self.config_dir, "*.json"))
            self.config_files = [os.path.basename(f) for f in config_files]
            self.logger.info(f"Found config files: {self.config_files}")
            print(f"Loading configs from: {self.config_files}")
            
            # Track if we've loaded all required files
            required_files = ['general.json', 'indicators.json', 'strategy.json', 'execution.json']
            loaded_required_files = []
            
            # Load each config file
            for config_file in config_files:
                config_name = os.path.basename(config_file).split('.')[0]  # Get filename without extension
                
                try:
                    with open(config_file, 'r') as f:
                        config_data = json.load(f)
                        
                    # Add to config under the file's name
                    self.config[config_name] = config_data
                    
                    # Log detailed config content at debug level
                    self.logger.debug(f"Loaded {config_name}.json: {json.dumps(config_data, indent=2)}")
                    
                    # Log at info level
                    self.logger.info(f"Loaded config from {config_name}.json")
                    
                    # Check if this is a required file
                    if f"{config_name}.json" in required_files:
                        loaded_required_files.append(f"{config_name}.json")
                except Exception as e:
                    self.logger.error(f"Error loading {config_file}: {str(e)}")
            
            # Check if all required files were loaded
            missing_files = [f for f in required_files if f not in loaded_required_files]
            if missing_files:
                self.logger.warning(f"Missing required config files: {missing_files}")
            
            if not self.config:
                raise RuntimeError(f"No configuration files found in {self.config_dir}")
            
            self.logger.debug(f"← load_configs returned config with {len(self.config)} sections")
            return self.config
            
        except Exception as e:
            self.logger.error(f"Failed to load configurations: {str(e)}")
            print(f"ERROR loading configs: {str(e)}")
            self.logger.debug(f"← load_configs returned empty config (error)")
            return {}
    
    def get_config(self, section: str = None) -> Any:
        """
        Get configuration or section
        
        Args:
            section: Optional section name
            
        Returns:
            Full config if no section provided, else specific section
        """
        self.logger.debug(f"→ get_config(section={section})")
        
        if not self.config:
            self.load_configs()
        
        if section:
            result = self.config.get(section, {})
            self.logger.debug(f"← get_config returned section '{section}' with {len(result)} keys")
            return result
        
        self.logger.debug(f"← get_config returned full config with {len(self.config)} sections")
        return self.config